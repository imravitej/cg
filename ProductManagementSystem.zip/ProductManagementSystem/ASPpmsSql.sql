create table aspProd(
ProductId int primary key,
ProductName varchar(20),
Price money,
)


insert into aspProd values (1,'TV',10000)