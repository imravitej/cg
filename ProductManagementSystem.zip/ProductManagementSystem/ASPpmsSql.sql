select * from aspPMS


create table aspPMS(
ProductId int identity(100000,1)primary key,
ProductName varchar(20),
Price money,
)

drop table aspPMS
create table LoginCred(UserName varchar(15) primary key, Passwrd varchar(15))
insert into LoginCred values('admin','admin')
insert into LoginCred values('tej','admin')

select * from LoginCred

delete aspPMS where ProductId=6



insert into aspPMS values ('TV',10000)
insert into aspPMS vALUES (234567,'Washing Machine',15000)
insert into aspPMS values(345678,'AC',17000)
insert into aspPMS values(456789,'Laptop',41000)
insert into aspPMS values(567891,'Computer',15000)
insert into aspPMS values(678910,'Fridge',20000)

select * from aspPMS

create proc getallPro
as
begin select * from aspPMS
end

create proc addPro(@name varchar(20),@price money)
as
begin 
insert into aspPMS values(@name,@price)
end

create proc updateprod(@name varchar(20),@price money,@id int)
as
begin
update aspPMS set ProductName=@name,Price=@price where ProductId=@id
end 

create proc deleteProd(@id int)
as
begin
delete from aspPMS where ProductId=@id
end

create proc searchProd(@id int)
as
begin
select * from aspPMS where ProductId=@id
end



