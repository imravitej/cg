﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PMS.Entity;
using PMS.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PMS.DAL
{
    public class ProductDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Pcon"].ConnectionString);
        SqlCommand cmd ;
        
        public List<ProductEntity> AllProducts()
        {
            
            
            List<ProductEntity> Plist = new List<ProductEntity>();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "getall";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();
                Plist = new List<ProductEntity>();
                while (dr.Read())
                {
                    ProductEntity p = new ProductEntity();
                    p.ProductId = dr.GetInt32(0);
                    p.ProductName = dr.GetString(1);
                    p.Price = dr.GetDecimal(2);
                    

                    Plist.Add(p);
                }
                
            }
            catch (System.Exception v)
            {

                throw new ProductExceptions(v.Message);
            }
            return Plist;
        }
        public bool AddProduct(ProductEntity Padd)
        {
            bool prodadded=false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "addAspProd";
                cmd.Parameters.AddWithValue("@id", Padd.ProductId);
                cmd.Parameters.AddWithValue("@name", Padd.ProductName);
                cmd.Parameters.AddWithValue("@price", Padd.Price);
                cmd.Connection = con;
                con.Open();
                int r = cmd.ExecuteNonQuery();
                con.Close();
                if (r > 0)
                    prodadded = true;
                
            }
            catch (Exception ex)
            {

                throw new ProductExceptions(ex.Message);
            }
            return prodadded;
        }
        public bool LoginCred(LoginClass cred)
        {
            try
            {
                cmd = new SqlCommand("select * from  HMS_NN.LoginCreds where USERNAME=@u AND PASS=@p", con);
                cmd.Parameters.AddWithValue("@u", cred.Username);
                cmd.Parameters.AddWithValue("@p", cred.Password);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    return true;

                }
                else
                {
                    con.Close();
                    return false;

                }
            }
            catch (ProductExceptions v)
            {
                con.Close();
                throw v;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
          
        }
    }
}
