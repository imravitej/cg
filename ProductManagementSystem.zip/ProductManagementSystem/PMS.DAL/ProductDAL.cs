﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PMS.Entity;
using PMS.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PMS.DAL
{
    public class ProductDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Pcon"].ConnectionString);
        SqlCommand cmd ;
        
        public List<ProductEntity> AllProducts()
        {
            
            
            List<ProductEntity> Plist = new List<ProductEntity>();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "getallPro";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();
                Plist = new List<ProductEntity>();
                while (dr.Read())
                {
                    ProductEntity p = new ProductEntity();
                    p.ProductId = dr.GetInt32(0);
                    p.ProductName = dr.GetString(1);
                    p.Price = dr.GetDecimal(2);
                    

                    Plist.Add(p);
                }
                
            }
            catch (System.Exception v)
            {

                throw new ProductExceptions(v.Message);
            }
            return Plist;
        }
        public bool AddProduct(ProductEntity Padd)
        {
            bool prodadded=false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "addPro";
              //  cmd.Parameters.AddWithValue("@id", Padd.ProductId);
                cmd.Parameters.AddWithValue("@name", Padd.ProductName);
                cmd.Parameters.AddWithValue("@price", Padd.Price);
                cmd.Connection = con;
                con.Open();
                int r = cmd.ExecuteNonQuery();
                con.Close();
                if (r > 0)
                    prodadded = true;
                
            }
            catch (Exception ex)
            {

                throw new ProductExceptions(ex.Message);
            }
            return prodadded;
        }
        public bool LoginCred(LoginClass cred)
        {
            try
            {
                cmd = new SqlCommand("select * from  LoginCred where UserName=@u AND Passwrd=@p", con);
                cmd.Parameters.AddWithValue("@u", cred.Username);
                cmd.Parameters.AddWithValue("@p", cred.Password);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    return true;

                }
                else
                {
                    con.Close();
                    return false;

                }
            }
            catch (ProductExceptions v)
            {
                con.Close();
                throw v;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
          
        }
        public bool UpdateProduct(ProductEntity prod)
        {
            bool proupdate = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "updateprod";
                cmd.Parameters.AddWithValue("@name", prod.ProductName);
                cmd.Parameters.AddWithValue("@price", prod.Price);
                cmd.Parameters.AddWithValue("@id", prod.ProductId);
                cmd.Connection=con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    proupdate = true;
            }
            catch (Exception ex)
            {

                throw new ProductExceptions(ex.Message);
            }
            return proupdate;
        }
        public bool DeleteProductDAL(int id)
        {
            bool prodel = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "deleteProd";
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    prodel = true;
            }
            catch (Exception ex)
            {

                throw new ProductExceptions(ex.Message);
            }
            return prodel;
        }
        public ProductEntity GetProd(int id)
        {
            ProductEntity p=null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "searchProd";
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if(dr.HasRows)
                {
                    dr.Read();
                    p= new ProductEntity();
                    p.ProductId = dr.GetInt32(0);
                    p.ProductName = dr.GetString(1);
                    p.Price = dr.GetDecimal(2);
                }

            }
            catch (Exception ex)
            {
                
                throw new ProductExceptions(ex.Message);
            }
            return p;
        }
        public int Pid()
        {
            con.Open();
            cmd = new SqlCommand("select ident_current('aspPMS')",con);

            int ret = Convert.ToInt32(cmd.ExecuteScalar())+1;
            con.Close();
            return ret;


        }
    }
}
