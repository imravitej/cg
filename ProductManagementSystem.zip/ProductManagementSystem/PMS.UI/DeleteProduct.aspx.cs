﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PMS.BLL;
using PMS.Entity;
using PMS.Exceptions;

namespace PMS.UI
{
    public partial class DeleteProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtPid.Text);
                bool status = ProductBL.DeleteProductBL(id);
                if(status)
                {
                    lblRecordDeleted.Text = "Product ID : " + txtPid.Text.ToString() + "details deleted successfully.";
                    txtPid.Text = "";
                }
                else
                    lblRecordDeleted.Text = "Record not deleted for Product ID : " + txtPid.Text.ToString();
            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}