﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using PMS.Exceptions;
using PMS.BLL;
using PMS.Entity;

namespace PMS.UI
{
    public partial class SearchProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtPid.Text);
                ProductEntity ps = ProductBL.GetProdBL(id);

                if (ps != null)
                {
                    lblSearch.Text = "Details of Product ID : " + txtPid.Text.ToString();
                    lblPnam.Text = "Product Name :";
                    lblPrice.Text = "Price        :";
                    txtPname.Text = ps.ProductName;
                    txtPrice.Text = ps.Price.ToString();

                }
                else
                {
                    lblSearch.Text = "No product found with ID : " + txtPid.Text.ToString();
                    lblPnam.Text = " ";
                    lblPrice.Text = " ";
                    txtPname.Text = " ";
                    txtPrice.Text = " ";
                }

            }
            catch (Exception)
            {
                
                throw;
            }
            
                      
        }
    }
}