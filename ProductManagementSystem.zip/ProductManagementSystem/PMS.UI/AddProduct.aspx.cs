﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using PMS.Entity;
using PMS.BLL;
using PMS.Exceptions;

namespace PMS.UI
{
    public partial class AddProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                ProductEntity p = new ProductEntity();
                p.ProductId = Convert.ToInt32(txtpid.Text);
                p.ProductName = txtpname.Text;
                p.Price = Convert.ToDecimal(txtprice.Text);

                bool status = ProductBL.AddProductBL(p);
                if (status)
                {
                    lblRecordAdded.Text = "Record Added successfully for Product ID : " + txtpid.Text.ToString();
                    txtpid.Text = "";
                    txtpname.Text = "";
                    txtprice.Text = "";
                }
                else
                    lblRecordAdded.Text = "Record not added for Product ID : " + txtpid.Text.ToString();

            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}