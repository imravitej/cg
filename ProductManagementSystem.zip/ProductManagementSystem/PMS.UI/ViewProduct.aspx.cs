﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using PMS.Entity;
using PMS.BLL;
using PMS.Exceptions;

namespace PMS.UI
{
    public partial class ViewProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                System.Threading.Thread.Sleep(1000);
                List<ProductEntity> p =ProductBL.AllProductsBL();
                GridView1.DataSource = p;
                GridView1.DataBind();
            }
            catch (System.Exception)
            {                
                throw;
            }
            
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void G(object sender, GridViewPageEventArgs e)
        {

        }

        protected void GColumn0Column1Column2abcabcabcabcabcabcabcabcabcabcabcabcabcabcabc(object sender, GridViewPageEventArgs e)
        {

        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.DataSource = ProductBL.AllProductsBL();
            GridView1.PageIndex = e.NewPageIndex;
            GridView1.DataBind();
        }

        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }
    }
}