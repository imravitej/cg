﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using PMS.BLL;
using PMS.Entity;
using PMS.Exceptions;

namespace PMS.UI
{
    public partial class UpdateProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ProductEntity up = new ProductEntity();
                up.ProductName = txtPname.Text;
                up.Price = Convert.ToDecimal(txtPrice.Text);
                up.ProductId = Convert.ToInt32(txtPid.Text);


                bool status = ProductBL.UpdateProductBL(up);
                if (status)
                {
                    lblRecordUpdated.Text = "Product ID : " + txtPid.Text.ToString()+"details updated successfully.";
                    txtPid.Text = "";
                    txtPname.Text = "";
                    txtPrice.Text = "";
                }
                else
                    lblRecordUpdated.Text = "Record not updated for Product ID : " + txtPid.Text.ToString();


            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}