﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using PMS.Exceptions;
using PMS.BLL;
using PMS.Entity;
using System.Web.Security;

namespace PMS.UI
{
    public partial class Login : System.Web.UI.Page
    {

        ProductBL b = new ProductBL();
        LoginClass l = new LoginClass();
            
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            l.Username = txtUname.Text;
            l.Password = txtPwd.Text;
            if(b.LoginCred(l))
            {
                //HttpCookie cookie = new HttpCookie("cookie", txtUname.Text);
                //cookie.Expires = System.DateTime.Now.AddMinutes(5);
                //Response.Cookies.Add(cookie);
                FormsAuthentication.RedirectFromLoginPage(txtUname.Text, false);
                Session["a"] = this.txtUname.Text;
              //  Response.Redirect("Home.aspx");
            }
            else
            {
                lblmsg.Text = "Login Failed";
            }
            
           
            
            
            
            
        }
    }
}