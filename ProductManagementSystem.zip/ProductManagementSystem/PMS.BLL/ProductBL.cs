﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PMS.Entity;
using PMS.Exceptions;
using System.Text.RegularExpressions;
using PMS.DAL;
using System.Data.SqlClient;
namespace PMS.BLL
{
    public class ProductBL
    {
        public static bool Validate(ProductEntity p)
        {
            bool valid = true;
            StringBuilder sb=new StringBuilder();
            var ProReExp = new Regex("^[A-Za-z]+$");
            if(ProReExp.IsMatch(p.ProductName)!=true)
            {
                valid = false;
                sb.Append("Product name should have characters");
            }
            var i=new Regex("^[0-9]{6}");
            if(i.IsMatch(p.ProductId.ToString())!=true)
            {
                valid = false;
                sb.Append("Product Id must be 6 digits");
            }
            if (valid == false)
                throw new ProductExceptions(sb.ToString());
            return valid;

        }
        public static bool AddProductBL(ProductEntity p)
        {
            bool proadded = false;
            try
            {
                if(Validate(p))
                {
                    ProductDAL obj = new ProductDAL();
                    proadded = obj.AddProduct(p);
                }
            }
            catch (Exception ex)
            {
                
                throw new ProductExceptions(ex.Message);
            }
            return proadded;
        }
        public static List<ProductEntity> AllProductsBL()
        {
            List<ProductEntity> Plist =null;
            try
            {
                ProductDAL Pdal = new ProductDAL();
                Plist = Pdal.AllProducts();
            }
                catch(ProductExceptions v)
            {
                throw v;
            }
            catch (Exception v)
            {

                throw new ProductExceptions(v.Message);
            }
            return Plist;
        }
        public bool LoginCred(LoginClass cred)
        {
            try
            {
                ProductDAL Pdal = new ProductDAL();
                return Pdal.LoginCred(cred);
            }
                catch(ProductExceptions p)
            {
                throw new ProductExceptions(p.Message);
            }
            catch (SqlException e)
            {
                throw e;
            }
            catch(System.Exception)
            {
                throw ;
            }

        }
    }
}
