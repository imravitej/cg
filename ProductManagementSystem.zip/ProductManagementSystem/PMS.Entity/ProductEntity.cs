﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Entity
{
    public class ProductEntity
    {
       private int productId;
       private string productName;
       private decimal price;

        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        public string ProductName
        {
            get { return productName; }
            set { productName = value; }
        }

        public int ProductId
        {
            get { return productId; }
            set { productId = value; }
        }

    }
}
